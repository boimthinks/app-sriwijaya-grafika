-- Sriwijaya Grafika Database Schema
-- Jalankan jika database belum ada:
-- CREATE DATABASE IF NOT EXISTS sgrafika DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tambah kolom yang mungkin belum ada di proyek_item
ALTER TABLE proyek_item ADD COLUMN IF NOT EXISTS kategori VARCHAR(20) DEFAULT 'barang' AFTER barang_id;
ALTER TABLE proyek_item ADD COLUMN IF NOT EXISTS satuan VARCHAR(20) DEFAULT '' AFTER qty;

-- Tabel pembayaran bertahap (untuk SK Pasal 4)
CREATE TABLE IF NOT EXISTS proyek_term (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proyek_id INT NOT NULL,
  urutan INT NOT NULL,
  deskripsi VARCHAR(200) DEFAULT '',
  dasar ENUM('barang','pekerjaan','grand_total') DEFAULT 'barang',
  persen DECIMAL(5,2) DEFAULT 0,
  jumlah DECIMAL(15,2) DEFAULT 0,
  FOREIGN KEY (proyek_id) REFERENCES proyek(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Pastikan counter_dokumen sudah benar
CREATE TABLE IF NOT EXISTS counter_dokumen (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_id INT NOT NULL,
  jenis VARCHAR(10) NOT NULL COMMENT 'sp, sk, inv, sj, ba',
  tahun YEAR NOT NULL,
  nomor_terakhir INT NOT NULL DEFAULT 0,
  UNIQUE KEY (entity_id, jenis, tahun),
  FOREIGN KEY (entity_id) REFERENCES entity(id)
) ENGINE=InnoDB;
